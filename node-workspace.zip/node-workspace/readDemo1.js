var fs = require('fs');

var path = "C:/node-workspace/holidays.txt";

//function declaration
function handleData(err,content){
	if(err){
		console.log("Error in reading file!!!!!");
		throw new Error("Error in file!!!!");
	}
	console.log("File reading completed!!!!");
	if(Buffer.isBuffer(content))
		console.log(content.toString());
	else
		console.log(content);
	
	console.log("sending mail with content");
}

fs.readFile(path,handleData);
//fs.readFile(path,'UTF8',handleData);

console.log("Finish Line!");


