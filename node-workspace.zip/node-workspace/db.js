var mysql = require('mysql');

var con = mysql.createConnection({
  host     : 'localhost',
  database: 'ibm',
  port : 3306,	
  user     : 'root',
  password : 'root'
});

con.connect(function(err){
	if(err){
		console.log("Error in Connection!!!");	
		throw err;
	}
	console.log("Connected to DB!!!");
	fetchData();
});


function fetchData(){
	con.query("select * from politician_secret",function(err,records){
		console.log(records);	
		con.end();
		console.log("Disconnected from DB!!!");	
	});	
}