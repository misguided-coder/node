var fs = require('fs');

var readPath = "C:/node-workspace/holidays1.txt";
var writePath = "C:/node-workspace/holidays1-out.txt";

var readStream = fs.createReadStream(readPath,{encoding:'UTF8',autoClose:false});
var writeStream = fs.createWriteStream(writePath,'UTF8');

readStream.pipe(writeStream);

