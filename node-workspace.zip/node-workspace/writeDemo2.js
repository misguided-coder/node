var fs = require('fs');

var path = "C:/node-workspace/cricket.txt";

var content = "Cricket is good for fun.";

fs.writeFile(path,content,function (err){
	if(err){
		console.log("Error in File writing!");
		throw err;
	}
	console.log("File writing done!");
	console.log("SMS sent!!!");
});

console.log("Finish Line!");