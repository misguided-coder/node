var fs = require('fs');

var path1 = "C:/node-workspace/holidays.txt"; //10 GB
var path2 = "C:/node-workspace/movies.txt";  //10 KB

function handleHolidayData(err,content){
	console.log("Holiday File reading completed!!!!");
	console.log(content);
}

function handleMovieData(err,content){
	console.log("Movie File reading completed!!!!");
	console.log(content);
}

console.log("Check Point 1");
fs.readFile(path1,'UTF8',handleHolidayData);
console.log("Check Point 2");
fs.readFile(path2,'UTF8',handleMovieData);
console.log("Finish Line!");

