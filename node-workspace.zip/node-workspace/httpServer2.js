var http = require('http');
var url = require('url');
var qs = require('querystring');


var server = http.createServer();

server.on('request',function(req,res){
	console.log("Client request received!!!");
	console.log(req.url);
	var urlObj = url.parse(req.url);
	console.log(urlObj.pathname);
	console.log(urlObj.query);

	var queryObj = qs.parse(urlObj.query);
	console.log(queryObj);

	res.writeHead(200,{'Content-Type':'text/html'});
	if(urlObj.pathname.indexOf('weather') > -1){
		res.write("<div style='color:red'><h1>Weather is very cool in city "+queryObj.city+".</h1></div>");
	}else if(urlObj.pathname.indexOf('news') > -1){
		res.write("<div style='color:red'><h1>Breaking News - Training will finish at 9 PM.</h1></div>");
	}
	res.end();
	
});

server.listen(5000,function(){
	console.log("Fastest Server is up....");
});



