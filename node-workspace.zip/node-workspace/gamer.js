var racer = require('./racer');

var racer1 = racer.createCarRacer();

racer1.on('racingStarted',function(){
	console.log("Enjoy the race........");
});


setTimeout(function(){
	racer1.gameStarted();	
},5000);





