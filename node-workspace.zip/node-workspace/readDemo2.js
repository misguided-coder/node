var fs = require('fs');

var path = "C:/node-workspace/holidays.txt";

try{
	var content = fs.readFileSync(path);
	console.log(content.toString());
}catch(err){
	console.log(err.message);
	console.log("Error in reading file!!!!!");
}
console.log("Finish Line!");


