function greet(){
	console.log("Happy Nodejs learning!!!!!");
}


greet();


