var fs = require('fs');

var path = "C:/node-workspace/cricket.txt";

var content = "Cricket is good for fun.";

function completeWork(err){
	if(err){
		console.log("Error in File writing!");
		throw err;
	}
	console.log("File writing done!");
	console.log("SMS sent!!!");
}

fs.writeFile(path,content,completeWork);

console.log("Finish Line!");