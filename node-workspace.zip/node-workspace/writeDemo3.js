var fs = require('fs');

var path = "C:/node-workspace/cricket.txt";

var content = "Cricket is good for fun.";

//fs.writeFileSync(path,content);
fs.appendFileSync(path,content);

console.log("File writing done!");
console.log("SMS sent!!!");

console.log("Finish Line!");