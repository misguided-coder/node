for(var i=0;i<=10;i++){
	console.log(i);
}

var age = 30;

if(age <= 12){
	console.log("Not eligible for Movie, Go Home....");
}else{
	console.log("Enjoy Movie with popcorn...");
}

console.log(new Date());

console.log(Math.random());
console.log(Math.min(10,6));
console.log(Math.max(10,6));
console.log(Math.floor(12.90));


var arr = new Array(23,56,23,23,46,67,78,789,8);
console.log(arr);
arr.pop();
console.log(arr);
arr.push(10);
arr.push(20);
console.log(arr);




