var title = "Math Calculator";

function sum(a,b){
	console.log("SUM : "+(a+b));
}

function diff(a,b){
	console.log("DIFF : "+(a-b));
}



exports.title = title;
exports.doSum = sum;
exports.doDiff = diff;
exports.doMultiply = function (a,b){
	console.log("Multiply : "+(a*b));
};


