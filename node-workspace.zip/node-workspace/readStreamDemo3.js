var fs = require('fs');

var path = "C:/node-workspace/holidays1.txt";

var readStream = fs.createReadStream(path,'UTF8');

var count = 0;

readStream.on('error',function (err){
	console.log("Error in File processing!!");
});

readStream.on('close',function (){
	console.log("File closed!!");
	console.log(count);
});

readStream.on('data',function (content){
	//console.log("File is being read!!!!");
	count++;
});

readStream.on('end',function (){
	console.log("File reading completed!!!!");
});

readStream.addListener('open',function (){
	console.log("File opened successfully!!!!!");
});

console.log("Finish Line!");


