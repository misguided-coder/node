var fs = require('fs');

var path = "C:/node-workspace/holidays.txt";

//var readStream = fs.createReadStream(path,'UTF8');
var readStream = fs.createReadStream(path,{start:5,end:15,autoClose:false,encoding:'UTF8'});

readStream.on('error',function (err){
	console.log("Error in File processing!!");
});

readStream.on('close',function (){
	console.log("File closed!!");
});

readStream.addListener('data',function (content){
	console.log("File is being read!!!!");
	if(Buffer.isBuffer(content))
		console.log(content.toString());
	else
		console.log(content);
});

readStream.on('end',function (){
	console.log("File reading completed!!!!");
	readStream.close();
});

readStream.addListener('open',function (){
	console.log("File opened successfully!!!!!");
});

console.log("Finish Line!");


