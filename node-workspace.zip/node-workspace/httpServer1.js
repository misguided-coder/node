var http = require('http');

var server = http.createServer();

server.on('request',function(req,res){
	console.log("Client request received!!!");
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<div style='color:red'><h1>Hello from Node Web Server.</h1></div>");
	res.end();
});

server.listen(5000);

console.log("Fastest Server is up....");


