var http = require('http');
var url = require('url');
var qs = require('querystring');
var fs = require('fs');

var server = http.createServer();

var location = "public/";

server.on('request',function(req,res){

	var urlObj = url.parse(req.url);
	res.writeHead(200,{'Content-Type':'text/html'});

	if(urlObj.pathname.indexOf('weather') > -1){
		var readStream = fs.createReadStream(location+'weather.html');
		readStream.pipe(res);
	}else if(urlObj.pathname.indexOf('cricket') > -1){
		var readStream = fs.createReadStream(location+'cricket.html');
		readStream.pipe(res);
	}else{
		var readStream = fs.createReadStream(location+'404.html');
		readStream.pipe(res);
	}
	
});

server.listen(5000,function(){
	console.log("Fastest Server is up....");
});



