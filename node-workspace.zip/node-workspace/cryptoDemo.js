var crypto = require('crypto');

var hash = crypto.createHash("SHA512");

var plainText = "$200 million in swiss account";

hash.update(plainText,"UTF8");

var digestText = hash.digest('hex');

console.log(digestText);