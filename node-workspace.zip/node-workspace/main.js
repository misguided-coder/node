var math = require('./math.js');
var circle = require('./shape/circle');

console.log("Inside main.....");

console.log(math.title);
math.doSum(2,2);
console.log(math.doSum);
math.doDiff(20,2);
math.doMultiply(20,2);

//var c1 = new circle.Circle(50);
var c1 = circle.createCircle(50);
c1.info();
c1.area();

//var c2 = new circle.Circle(100);
var c2 = circle.createCircle(100);
c2.info();
c2.area();

