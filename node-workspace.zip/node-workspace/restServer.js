var express = require('express');
var mysql = require('mysql');

var con = mysql.createConnection({
  host     : 'localhost',
  database: 'ibm',
  port : 3306,	
  user     : 'root',
  password : 'root'
});

var server =  express();
con.connect(function(err){
	if(err){
		console.log("Error in Connection!!!");	
		throw err;
	}
	console.log("Connected to DB!!!");
});

server.get('/politicians',function(req,res){
	con.query("select * from politician_secret",function(err,records){
		res.json(records);	
	});	
});

server.get('/politicians/:id',function(req,res){
	var pid = req.params['id'];
	con.query("select * from politician_secret where id="+pid,function(err,records){
		res.json(records);	
	});	
});

server.get('/politician',function(req,res){
	res.json({'id':1,'name':'Raja','frauds':500});	
});

server.get('/politician/:id',function(req,res){
	var pid = req.params['id'];
	res.json({'id':pid,'name':'Sonia','frauds':520});	
});

server.listen(5000,function(){
	console.log("Rest Server is up.... on port 5000");
});



