var fs = require('fs');

var path = "C:/node-workspace/cricket.txt";

var writeStream = fs.createWriteStream(path,'UTF8');

writeStream.write("Cricket is a good business."); 
writeStream.write("Cricket is a good business."); 
writeStream.write("Cricket is a good business."); 
writeStream.write("Cricket is a good business."); 
writeStream.write("Cricket is a good business."); 
writeStream.write("Cricket is a good business."); 
writeStream.end(); 


writeStream.on('error',function (err){
	console.log("Error in File processing!!");
});

writeStream.on('close',function (){
	console.log("File closed!!");
});

writeStream.on('finish',function (){
	console.log("File writing finished!!!!");
});

writeStream.on('open',function (){
	console.log("File opened successfully!!!!!");
});

console.log("Finish Line!");


