var fs = require('fs');

var readPath = "C:/node-workspace/holidays1.txt";
var writePath = "C:/node-workspace/holidays1-out.txt";

var readStream = fs.createReadStream(readPath,{encoding:'UTF8',autoClose:false});
var writeStream = fs.createWriteStream(writePath,'UTF8');

var fileStatus = false;

writeStream.on('open',function (){
	console.log("File writing opened successfully!!!!!");
	fileStatus = true;
	readStream.resume();	
});

writeStream.on('error',function (err){
	console.log("Error in File writing ");
	readStream.close();
});

readStream.on('error',function (err){
	console.log("Error in File processing!!");
	writeStream.end();
});

readStream.on('close',function (){
	console.log("File reading closed!!");
});

var content = '';

readStream.on('data',function (chunk){
	content += chunk;
	if(fileStatus){
		writeStream.write(content);
		content = '';
	}else{
		readStream.pause();	
	}
});

readStream.on('end',function (){
	console.log("File reading completed!!!!");
	writeStream.end();
});

readStream.on('open',function (){
	console.log("File reading opened successfully!!!!!");
});

writeStream.on('finish',function (){
	console.log("File writing completed!!!!");
});

console.log("Finish Line!");


