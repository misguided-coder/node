var events = require('events');

class CarRacer extends events.EventEmitter{
	
	gameStarted(){
		this.emit('racingStarted');
		console.log("Game just started!!!");
		//100 loc
		
	}

	racerJoined(){
		this.emit('racerAdded');
		console.log("New Racer just joined the race!!!");
		//100 loc
	}

	racerWin(){
		this.emit('racerWon');
		console.log("Racer just won the match!!!");
		//100 loc
	}
}


exports.createCarRacer = function(){
	return new CarRacer();
}