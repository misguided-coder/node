class Circle{

	constructor(radius){
		console.log("Inside Circle parmetric constructor!!!!");
		this.radius = radius;
		this.color = 'Black';
	}

	info(){
		console.log("Radius : "+this.radius);
		console.log("Color : "+this.color);
	}

	area(){
		console.log("Area : "+(this.radius*this.radius*Math.PI));
	}

}


//exports.Circle = Circle;
exports.createCircle = function(radius){
	return new Circle(radius);
};

